   
   //alert("mano, cuidado com o tumalaka, ele é perigoso");

   
    var titulo = document.querySelector(".titulo");
    console.log(titulo.textContent);

    titulo.textContent = makeid(5);



    var nomedoarquivo = document.querySelector(".beneficios");
    var nome = nomedoarquivo.querySelector(".itens1");

    var valor = nomedoarquivo.querySelector(".itens2");
    console.log(nome);
    console.log(valor);

nome.textContent = makeid(5);
valor.textContent = Math.random(0,200);

var valor2 = nomedoarquivo.querySelector(".itens3");
var result = nomedoarquivo.querySelector(".itens4");

valor2.textContent = Math.random(0,200);
var tval = valor+ valor2;
result.textContent = tval;

//Math.round(Math.random(0,200)


    //console.log(nomedoarquivo);

    //console.log(nomedoarquivo.textContent);
    //nomedoarquivo.textContent = "ello";   



    var update = 1;
    var maxrate = 3;

    setInterval(draw, 0.1);


    function draw()
    {
        
        if(update > maxrate){
        //titulo.textContent = Math.round(Math.random(0,200));


            update = 1;
        } else {
            update += 0.1;
        }
    }

    function makeid(length) {
        var result           = '';
        var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < length; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    }
    
    console.log(makeid(5));